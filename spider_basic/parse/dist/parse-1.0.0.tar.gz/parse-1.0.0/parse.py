def print_multiple_list(items):
    for item in items:
        # 判断item是否为list类型
        if isinstance(item, list):
            print_multiple_list(item)
        else:
            print(item)


